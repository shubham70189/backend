import { Call } from '@angular/compiler';
import { CallEnum, CallMeetingStatus, LeadSource, LeadsStatus, PromptTypeEnum, TenantAvailabilityState, TimeType } from '@shared/service-proxies/service-proxies';


export class AppTenantAvailabilityState {
    static Available: number = TenantAvailabilityState._1;
    static InActive: number = TenantAvailabilityState._2;
    static NotFound: number = TenantAvailabilityState._3;
}

export class CallEnumState{
    static All = undefined;
    static Inbound = CallEnum._0;
    static Outbound = CallEnum._1;

}
export class PromptTypeEnumState{
    static RealEstate = PromptTypeEnum._0;
    static HR = PromptTypeEnum._1;
    static Restaurant = PromptTypeEnum._2;
    static Other = PromptTypeEnum._3;
    static Appointment = PromptTypeEnum._4;

    
}

export class CallMeetingEnumStatus{
    static OnlineMeetingSch = CallMeetingStatus._0;
    static OfflineMeetingSc = CallMeetingStatus._1;
    static Connected = CallMeetingStatus._2;
    static NotAns = CallMeetingStatus._3;
}

export class LeadsSourceEnum
{
   
   static Manual= LeadSource._0;
   static Meta= LeadSource._1;
    static Google = LeadSource._2;
    static Hubspot = LeadSource._3;
    
}

export class LeadSourceEnumState{
    static Manual = LeadSource._0;
    static Meta = LeadSource._1;
    static Google = LeadSource._2;
    static Hubspot = LeadSource._3;
    
    static getEnumName(value: LeadSource): string | undefined {
        // Iterate over the class properties
        for (const key in LeadSourceEnumState) {
            if (LeadSourceEnumState.hasOwnProperty(key) && LeadSourceEnumState[key] === value) {
                return key;
            }
        }
        return undefined; // Return undefined if no match is found
    }
}
export class LeadStatusEnumState{
    static New = LeadsStatus._0
    static NotQualified = LeadsStatus._1;
    static Qualified = LeadsStatus._2;
    
    
    static getEnumName(value: LeadsStatus): string | undefined {
        // Iterate over the class properties
        for (const key in LeadStatusEnumState) {
            if (LeadStatusEnumState.hasOwnProperty(key) && LeadStatusEnumState[key] === value) {
                return key;
            }
        }
        return undefined; // Return undefined if no match is found
    }
}


export class TimeTypeEnumState{
    static Sec = TimeType._0
    static Min = TimeType._1
    static Hour = TimeType._2;
    static Day = TimeType._3;    
}

export class EnumHelper {
    static getEnumName<T>(enumObj: T, value: T[keyof T]): string | undefined {
      // Iterate over the keys of the enum object
      for (const key in enumObj) {
        if (Object.prototype.hasOwnProperty.call(enumObj, key) && enumObj[key] === value) {
          return key;
        }
      }
      return undefined; // Return undefined if no match is found
    }
  }

