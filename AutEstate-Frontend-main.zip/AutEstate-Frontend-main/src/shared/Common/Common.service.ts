import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CallMeetingEnumStatus, PromptTypeEnumState } from '@shared/AppEnums';

@Injectable()
export class CommonService {
    private apiUrl = 'https://restcountries.com/v3.1/all'; // API URL

    countries = [
        {
            "countryName": "Afghanistan",
            "phoneCode": "+93"
        },
        {
            "countryName": "Åland Islands",
            "phoneCode": "+35818"
        },
        {
            "countryName": "Albania",
            "phoneCode": "+355"
        },
        {
            "countryName": "Algeria",
            "phoneCode": "+213"
        },
        {
            "countryName": "American Samoa",
            "phoneCode": "+1684"
        },
        {
            "countryName": "Andorra",
            "phoneCode": "+376"
        },
        {
            "countryName": "Angola",
            "phoneCode": "+244"
        },
        {
            "countryName": "Anguilla",
            "phoneCode": "+1264"
        },
        {
            "countryName": "Antigua and Barbuda",
            "phoneCode": "+1268"
        },
        {
            "countryName": "Argentina",
            "phoneCode": "+54"
        },
        {
            "countryName": "Armenia",
            "phoneCode": "+374"
        },
        {
            "countryName": "Aruba",
            "phoneCode": "+297"
        },
        {
            "countryName": "Australia",
            "phoneCode": "+61"
        },
        {
            "countryName": "Austria",
            "phoneCode": "+43"
        },
        {
            "countryName": "Azerbaijan",
            "phoneCode": "+994"
        },
        {
            "countryName": "Bahamas",
            "phoneCode": "+1242"
        },
        {
            "countryName": "Bahrain",
            "phoneCode": "+973"
        },
        {
            "countryName": "Bangladesh",
            "phoneCode": "+880"
        },
        {
            "countryName": "Barbados",
            "phoneCode": "+1246"
        },
        {
            "countryName": "Belarus",
            "phoneCode": "+375"
        },
        {
            "countryName": "Belgium",
            "phoneCode": "+32"
        },
        {
            "countryName": "Belize",
            "phoneCode": "+501"
        },
        {
            "countryName": "Benin",
            "phoneCode": "+229"
        },
        {
            "countryName": "Bermuda",
            "phoneCode": "+1441"
        },
        {
            "countryName": "Bhutan",
            "phoneCode": "+975"
        },
        {
            "countryName": "Bolivia",
            "phoneCode": "+591"
        },
        {
            "countryName": "Bosnia and Herzegovina",
            "phoneCode": "+387"
        },
        {
            "countryName": "Botswana",
            "phoneCode": "+267"
        },
        {
            "countryName": "Bouvet Island",
            "phoneCode": "+47"
        },
        {
            "countryName": "Brazil",
            "phoneCode": "+55"
        },
        {
            "countryName": "British Indian Ocean Territory",
            "phoneCode": "+246"
        },
        {
            "countryName": "British Virgin Islands",
            "phoneCode": "+1284"
        },
        {
            "countryName": "Brunei",
            "phoneCode": "+673"
        },
        {
            "countryName": "Bulgaria",
            "phoneCode": "+359"
        },
        {
            "countryName": "Burkina Faso",
            "phoneCode": "+226"
        },
        {
            "countryName": "Burundi",
            "phoneCode": "+257"
        },
        {
            "countryName": "Cambodia",
            "phoneCode": "+855"
        },
        {
            "countryName": "Cameroon",
            "phoneCode": "+237"
        },
        {
            "countryName": "Canada",
            "phoneCode": "+1"
        },
        {
            "countryName": "Cape Verde",
            "phoneCode": "+238"
        },
        {
            "countryName": "Caribbean Netherlands",
            "phoneCode": "+599"
        },
        {
            "countryName": "Cayman Islands",
            "phoneCode": "+1345"
        },
        {
            "countryName": "Central African Republic",
            "phoneCode": "+236"
        },
        {
            "countryName": "Chad",
            "phoneCode": "+235"
        },
        {
            "countryName": "Chile",
            "phoneCode": "+56"
        },
        {
            "countryName": "China",
            "phoneCode": "+86"
        },
        {
            "countryName": "Christmas Island",
            "phoneCode": "+61"
        },
        {
            "countryName": "Cocos (Keeling) Islands",
            "phoneCode": "+61"
        },
        {
            "countryName": "Colombia",
            "phoneCode": "+57"
        },
        {
            "countryName": "Comoros",
            "phoneCode": "+269"
        },
        {
            "countryName": "Cook Islands",
            "phoneCode": "+682"
        },
        {
            "countryName": "Costa Rica",
            "phoneCode": "+506"
        },
        {
            "countryName": "Croatia",
            "phoneCode": "+385"
        },
        {
            "countryName": "Cuba",
            "phoneCode": "+53"
        },
        {
            "countryName": "Curaçao",
            "phoneCode": "+599"
        },
        {
            "countryName": "Cyprus",
            "phoneCode": "+357"
        },
        {
            "countryName": "Czechia",
            "phoneCode": "+420"
        },
        {
            "countryName": "Denmark",
            "phoneCode": "+45"
        },
        {
            "countryName": "Djibouti",
            "phoneCode": "+253"
        },
        {
            "countryName": "Dominica",
            "phoneCode": "+1767"
        },
        {
            "countryName": "Dominican Republic",
            "phoneCode": "+1809"
        },
        {
            "countryName": "DR Congo",
            "phoneCode": "+243"
        },
        {
            "countryName": "Ecuador",
            "phoneCode": "+593"
        },
        {
            "countryName": "Egypt",
            "phoneCode": "+20"
        },
        {
            "countryName": "El Salvador",
            "phoneCode": "+503"
        },
        {
            "countryName": "Equatorial Guinea",
            "phoneCode": "+240"
        },
        {
            "countryName": "Eritrea",
            "phoneCode": "+291"
        },
        {
            "countryName": "Estonia",
            "phoneCode": "+372"
        },
        {
            "countryName": "Eswatini",
            "phoneCode": "+268"
        },
        {
            "countryName": "Ethiopia",
            "phoneCode": "+251"
        },
        {
            "countryName": "Falkland Islands",
            "phoneCode": "+500"
        },
        {
            "countryName": "Faroe Islands",
            "phoneCode": "+298"
        },
        {
            "countryName": "Fiji",
            "phoneCode": "+679"
        },
        {
            "countryName": "Finland",
            "phoneCode": "+358"
        },
        {
            "countryName": "France",
            "phoneCode": "+33"
        },
        {
            "countryName": "French Guiana",
            "phoneCode": "+594"
        },
        {
            "countryName": "French Polynesia",
            "phoneCode": "+689"
        },
        {
            "countryName": "French Southern and Antarctic Lands",
            "phoneCode": "+262"
        },
        {
            "countryName": "Gabon",
            "phoneCode": "+241"
        },
        {
            "countryName": "Gambia",
            "phoneCode": "+220"
        },
        {
            "countryName": "Georgia",
            "phoneCode": "+995"
        },
        {
            "countryName": "Germany",
            "phoneCode": "+49"
        },
        {
            "countryName": "Ghana",
            "phoneCode": "+233"
        },
        {
            "countryName": "Gibraltar",
            "phoneCode": "+350"
        },
        {
            "countryName": "Greece",
            "phoneCode": "+30"
        },
        {
            "countryName": "Greenland",
            "phoneCode": "+299"
        },
        {
            "countryName": "Grenada",
            "phoneCode": "+1473"
        },
        {
            "countryName": "Guadeloupe",
            "phoneCode": "+590"
        },
        {
            "countryName": "Guam",
            "phoneCode": "+1671"
        },
        {
            "countryName": "Guatemala",
            "phoneCode": "+502"
        },
        {
            "countryName": "Guernsey",
            "phoneCode": "+44"
        },
        {
            "countryName": "Guinea",
            "phoneCode": "+224"
        },
        {
            "countryName": "Guinea-Bissau",
            "phoneCode": "+245"
        },
        {
            "countryName": "Guyana",
            "phoneCode": "+592"
        },
        {
            "countryName": "Haiti",
            "phoneCode": "+509"
        },
        {
            "countryName": "Honduras",
            "phoneCode": "+504"
        },
        {
            "countryName": "Hong Kong",
            "phoneCode": "+852"
        },
        {
            "countryName": "Hungary",
            "phoneCode": "+36"
        },
        {
            "countryName": "Iceland",
            "phoneCode": "+354"
        },
        {
            "countryName": "India",
            "phoneCode": "+91"
        },
        {
            "countryName": "Indonesia",
            "phoneCode": "+62"
        },
        {
            "countryName": "Iran",
            "phoneCode": "+98"
        },
        {
            "countryName": "Iraq",
            "phoneCode": "+964"
        },
        {
            "countryName": "Ireland",
            "phoneCode": "+353"
        },
        {
            "countryName": "Isle of Man",
            "phoneCode": "+44"
        },
        {
            "countryName": "Israel",
            "phoneCode": "+972"
        },
        {
            "countryName": "Italy",
            "phoneCode": "+39"
        },
        {
            "countryName": "Ivory Coast",
            "phoneCode": "+225"
        },
        {
            "countryName": "Jamaica",
            "phoneCode": "+1876"
        },
        {
            "countryName": "Japan",
            "phoneCode": "+81"
        },
        {
            "countryName": "Jersey",
            "phoneCode": "+44"
        },
        {
            "countryName": "Jordan",
            "phoneCode": "+962"
        },
        {
            "countryName": "Kazakhstan",
            "phoneCode": "+76"
        },
        {
            "countryName": "Kenya",
            "phoneCode": "+254"
        },
        {
            "countryName": "Kiribati",
            "phoneCode": "+686"
        },
        {
            "countryName": "Kosovo",
            "phoneCode": "+383"
        },
        {
            "countryName": "Kuwait",
            "phoneCode": "+965"
        },
        {
            "countryName": "Kyrgyzstan",
            "phoneCode": "+996"
        },
        {
            "countryName": "Laos",
            "phoneCode": "+856"
        },
        {
            "countryName": "Latvia",
            "phoneCode": "+371"
        },
        {
            "countryName": "Lebanon",
            "phoneCode": "+961"
        },
        {
            "countryName": "Lesotho",
            "phoneCode": "+266"
        },
        {
            "countryName": "Liberia",
            "phoneCode": "+231"
        },
        {
            "countryName": "Libya",
            "phoneCode": "+218"
        },
        {
            "countryName": "Liechtenstein",
            "phoneCode": "+423"
        },
        {
            "countryName": "Lithuania",
            "phoneCode": "+370"
        },
        {
            "countryName": "Luxembourg",
            "phoneCode": "+352"
        },
        {
            "countryName": "Macau",
            "phoneCode": "+853"
        },
        {
            "countryName": "Madagascar",
            "phoneCode": "+261"
        },
        {
            "countryName": "Malawi",
            "phoneCode": "+265"
        },
        {
            "countryName": "Malaysia",
            "phoneCode": "+60"
        },
        {
            "countryName": "Maldives",
            "phoneCode": "+960"
        },
        {
            "countryName": "Mali",
            "phoneCode": "+223"
        },
        {
            "countryName": "Malta",
            "phoneCode": "+356"
        },
        {
            "countryName": "Marshall Islands",
            "phoneCode": "+692"
        },
        {
            "countryName": "Martinique",
            "phoneCode": "+596"
        },
        {
            "countryName": "Mauritania",
            "phoneCode": "+222"
        },
        {
            "countryName": "Mauritius",
            "phoneCode": "+230"
        },
        {
            "countryName": "Mayotte",
            "phoneCode": "+262"
        },
        {
            "countryName": "Mexico",
            "phoneCode": "+52"
        },
        {
            "countryName": "Micronesia",
            "phoneCode": "+691"
        },
        {
            "countryName": "Moldova",
            "phoneCode": "+373"
        },
        {
            "countryName": "Monaco",
            "phoneCode": "+377"
        },
        {
            "countryName": "Mongolia",
            "phoneCode": "+976"
        },
        {
            "countryName": "Montenegro",
            "phoneCode": "+382"
        },
        {
            "countryName": "Montserrat",
            "phoneCode": "+1664"
        },
        {
            "countryName": "Morocco",
            "phoneCode": "+212"
        },
        {
            "countryName": "Mozambique",
            "phoneCode": "+258"
        },
        {
            "countryName": "Myanmar",
            "phoneCode": "+95"
        },
        {
            "countryName": "Namibia",
            "phoneCode": "+264"
        },
        {
            "countryName": "Nauru",
            "phoneCode": "+674"
        },
        {
            "countryName": "Nepal",
            "phoneCode": "+977"
        },
        {
            "countryName": "Netherlands",
            "phoneCode": "+31"
        },
        {
            "countryName": "New Caledonia",
            "phoneCode": "+687"
        },
        {
            "countryName": "New Zealand",
            "phoneCode": "+64"
        },
        {
            "countryName": "Nicaragua",
            "phoneCode": "+505"
        },
        {
            "countryName": "Niger",
            "phoneCode": "+227"
        },
        {
            "countryName": "Nigeria",
            "phoneCode": "+234"
        },
        {
            "countryName": "Niue",
            "phoneCode": "+683"
        },
        {
            "countryName": "Norfolk Island",
            "phoneCode": "+672"
        },
        {
            "countryName": "North Korea",
            "phoneCode": "+850"
        },
        {
            "countryName": "North Macedonia",
            "phoneCode": "+389"
        },
        {
            "countryName": "Northern Mariana Islands",
            "phoneCode": "+1670"
        },
        {
            "countryName": "Norway",
            "phoneCode": "+47"
        },
        {
            "countryName": "Oman",
            "phoneCode": "+968"
        },
        {
            "countryName": "Pakistan",
            "phoneCode": "+92"
        },
        {
            "countryName": "Palau",
            "phoneCode": "+680"
        },
        {
            "countryName": "Palestine",
            "phoneCode": "+970"
        },
        {
            "countryName": "Panama",
            "phoneCode": "+507"
        },
        {
            "countryName": "Papua New Guinea",
            "phoneCode": "+675"
        },
        {
            "countryName": "Paraguay",
            "phoneCode": "+595"
        },
        {
            "countryName": "Peru",
            "phoneCode": "+51"
        },
        {
            "countryName": "Philippines",
            "phoneCode": "+63"
        },
        {
            "countryName": "Pitcairn Islands",
            "phoneCode": "+64"
        },
        {
            "countryName": "Poland",
            "phoneCode": "+48"
        },
        {
            "countryName": "Portugal",
            "phoneCode": "+351"
        },
        {
            "countryName": "Puerto Rico",
            "phoneCode": "+1787"
        },
        {
            "countryName": "Qatar",
            "phoneCode": "+974"
        },
        {
            "countryName": "Republic of the Congo",
            "phoneCode": "+242"
        },
        {
            "countryName": "Réunion",
            "phoneCode": "+262"
        },
        {
            "countryName": "Romania",
            "phoneCode": "+40"
        },
        {
            "countryName": "Russia",
            "phoneCode": "+73"
        },
        {
            "countryName": "Rwanda",
            "phoneCode": "+250"
        },
        {
            "countryName": "Saint Barthélemy",
            "phoneCode": "+590"
        },
        {
            "countryName": "Saint Helena, Ascension and Tristan da Cunha",
            "phoneCode": "+290"
        },
        {
            "countryName": "Saint Kitts and Nevis",
            "phoneCode": "+1869"
        },
        {
            "countryName": "Saint Lucia",
            "phoneCode": "+1758"
        },
        {
            "countryName": "Saint Martin",
            "phoneCode": "+590"
        },
        {
            "countryName": "Saint Pierre and Miquelon",
            "phoneCode": "+508"
        },
        {
            "countryName": "Saint Vincent and the Grenadines",
            "phoneCode": "+1784"
        },
        {
            "countryName": "Samoa",
            "phoneCode": "+685"
        },
        {
            "countryName": "San Marino",
            "phoneCode": "+378"
        },
        {
            "countryName": "São Tomé and Príncipe",
            "phoneCode": "+239"
        },
        {
            "countryName": "Saudi Arabia",
            "phoneCode": "+966"
        },
        {
            "countryName": "Senegal",
            "phoneCode": "+221"
        },
        {
            "countryName": "Serbia",
            "phoneCode": "+381"
        },
        {
            "countryName": "Seychelles",
            "phoneCode": "+248"
        },
        {
            "countryName": "Sierra Leone",
            "phoneCode": "+232"
        },
        {
            "countryName": "Singapore",
            "phoneCode": "+65"
        },
        {
            "countryName": "Sint Maarten",
            "phoneCode": "+1721"
        },
        {
            "countryName": "Slovakia",
            "phoneCode": "+421"
        },
        {
            "countryName": "Slovenia",
            "phoneCode": "+386"
        },
        {
            "countryName": "Solomon Islands",
            "phoneCode": "+677"
        },
        {
            "countryName": "Somalia",
            "phoneCode": "+252"
        },
        {
            "countryName": "South Africa",
            "phoneCode": "+27"
        },
        {
            "countryName": "South Georgia",
            "phoneCode": "+500"
        },
        {
            "countryName": "South Korea",
            "phoneCode": "+82"
        },
        {
            "countryName": "South Sudan",
            "phoneCode": "+211"
        },
        {
            "countryName": "Spain",
            "phoneCode": "+34"
        },
        {
            "countryName": "Sri Lanka",
            "phoneCode": "+94"
        },
        {
            "countryName": "Sudan",
            "phoneCode": "+249"
        },
        {
            "countryName": "Suriname",
            "phoneCode": "+597"
        },
        {
            "countryName": "Svalbard and Jan Mayen",
            "phoneCode": "+4779"
        },
        {
            "countryName": "Sweden",
            "phoneCode": "+46"
        },
        {
            "countryName": "Switzerland",
            "phoneCode": "+41"
        },
        {
            "countryName": "Syria",
            "phoneCode": "+963"
        },
        {
            "countryName": "Taiwan",
            "phoneCode": "+886"
        },
        {
            "countryName": "Tajikistan",
            "phoneCode": "+992"
        },
        {
            "countryName": "Tanzania",
            "phoneCode": "+255"
        },
        {
            "countryName": "Thailand",
            "phoneCode": "+66"
        },
        {
            "countryName": "Timor-Leste",
            "phoneCode": "+670"
        },
        {
            "countryName": "Togo",
            "phoneCode": "+228"
        },
        {
            "countryName": "Tokelau",
            "phoneCode": "+690"
        },
        {
            "countryName": "Tonga",
            "phoneCode": "+676"
        },
        {
            "countryName": "Trinidad and Tobago",
            "phoneCode": "+1868"
        },
        {
            "countryName": "Tunisia",
            "phoneCode": "+216"
        },
        {
            "countryName": "Turkey",
            "phoneCode": "+90"
        },
        {
            "countryName": "Turkmenistan",
            "phoneCode": "+993"
        },
        {
            "countryName": "Turks and Caicos Islands",
            "phoneCode": "+1649"
        },
        {
            "countryName": "Tuvalu",
            "phoneCode": "+688"
        },
        {
            "countryName": "Uganda",
            "phoneCode": "+256"
        },
        {
            "countryName": "Ukraine",
            "phoneCode": "+380"
        },
        {
            "countryName": "United Arab Emirates",
            "phoneCode": "+971"
        },
        {
            "countryName": "United Kingdom",
            "phoneCode": "+44"
        },
        {
            "countryName": "United States",
            "phoneCode": "+1201"
        },
        {
            "countryName": "United States Minor Outlying Islands",
            "phoneCode": "+268"
        },
        {
            "countryName": "United States Virgin Islands",
            "phoneCode": "+1340"
        },
        {
            "countryName": "Uruguay",
            "phoneCode": "+598"
        },
        {
            "countryName": "Uzbekistan",
            "phoneCode": "+998"
        },
        {
            "countryName": "Vanuatu",
            "phoneCode": "+678"
        },
        {
            "countryName": "Vatican City",
            "phoneCode": "+3906698"
        },
        {
            "countryName": "Venezuela",
            "phoneCode": "+58"
        },
        {
            "countryName": "Vietnam",
            "phoneCode": "+84"
        },
        {
            "countryName": "Wallis and Futuna",
            "phoneCode": "+681"
        },
        {
            "countryName": "Western Sahara",
            "phoneCode": "+2125288"
        },
        {
            "countryName": "Yemen",
            "phoneCode": "+967"
        },
        {
            "countryName": "Zambia",
            "phoneCode": "+260"
        },
        {
            "countryName": "Zimbabwe",
            "phoneCode": "+263"
        }
    ]

    getRealEstatePrompt(companyName, userName, companyEmail){
        return [{"user":"assistant","text":`Hi, I'm ${userName} from ${companyName}. Am I speaking with Gautam?`},{"user":"user","text":"Yes."},{"user":"assistant","text":"Is this a good time to talk?"},{"user":"user","text":"Okay."},{"user":"user","text":"Sure."},{"user":"assistant","text":`At ${companyName}, we specialize in buying, selling, and renting properties. How can I assist you today?`},{"user":"user","text":"I want to buy a property."},{"user":"assistant","text":"Let's discuss your property requirements. Can you please tell me what your budget is for this property?"},{"user":"user","text":"It's around 50 lakhs."},{"user":"assistant","text":"What type of property are you looking for, and in which location?"},{"user":"user","text":"I'm looking for a 2 bedroom house."},{"user":"user","text":"In New Delhi."},{"user":"assistant","text":"Thank you for sharing all the details. I'll make sure our agents reach out to you soon with the best options that match your requirements. Is there a preferred time for our follow-up call?"},{"user":"user","text":"This weekend maybe around 11 AM."},{"user":"assistant","text":`Thank you, Gautam. We'll get in touch this weekend at 11 AM. If you need anything else in the meantime, feel free to contact us at ${companyEmail}. Have a wonderful day.`},{"user":"agent-action","text":"Ended call"}];
    }
    getHRPrompt(companyName, userName, companyEmail){
        return [
        {
            "id": 66762047,
            "user": "user",
            "text": "Hello?",
            "created_at": "2024-12-11T12:37:36.187872+00:00"
        },
        {
            "id": 66762050,
            "user": "assistant",
            "text": `Hello Gautam, my name is ${userName}, and I’m reaching out on behalf of ${companyName}. Could you please confirm if I’m speaking with the correct Gautam?`,
            "created_at": "2024-12-11T12:37:38.874827+00:00"
        },
        {
            "id": 66762057,
            "user": "user",
            "text": "Yes.",
            "created_at": "2024-12-11T12:37:45.465267+00:00"
        },
        {
            "id": 66762063,
            "user": "assistant",
            "text": `I'm calling today to discuss the Python Developer position you applied for at ${companyName}. I'd like to learn more about your experience and also share some details about the role with you. Is this a good time to talk?`,
            "created_at": "2024-12-11T12:37:51.737755+00:00"
        },
        {
            "id": 66762069,
            "user": "user",
            "text": "Yes. Sure.",
            "created_at": "2024-12-11T12:37:59.364195+00:00"
        },
        {
            "id": 66762075,
            "user": "assistant",
            "text": `Can you tell me a little bit about your recent experience, and what specifically drew you to apply for the Python Developer position at ${companyName}?`,
            "created_at": "2024-12-11T12:38:02.920452+00:00"
        },
        {
            "id": 66762084,
            "user": "user",
            "text": "Okay. So I have total experience of 4 years,",
            "created_at": "2024-12-11T12:38:15.17601+00:00"
        },
        {
            "id": 66762085,
            "user": "user",
            "text": "and, also, I'm a team lead at my company. I am leading a team of 15 people.",
            "created_at": "2024-12-11T12:38:17.521658+00:00"
        },
        
        {
            "id": 66762108,
            "user": "assistant",
            "text": "I'd like to shift gears a bit. As a team lead with 4 years of experience, you likely have a good sense of what you're looking for in a work environment. What are some key factors that you are looking",
            "created_at": "2024-12-11T12:38:38.337694+00:00"
        },
        {
            "id": 66762117,
            "user": "user",
            "text": "Yes.",
            "created_at": "2024-12-11T12:38:45.665841+00:00"
        },
        {
            "id": 66762121,
            "user": "assistant",
            "text": "What kind of company culture and work environment do you think would be the best fit for you, and what are your expectations for growth opportunities in your next role?",
            "created_at": "2024-12-11T12:38:50.765087+00:00"
        },
        {
            "id": 66762153,
            "user": "user",
            "text": "Okay. So for the environment part, I am doing, like, not so hectic. It won't work very well. So that will be good for me. And for the growth part, I want to learn, on the cloud part.",
            "created_at": "2024-12-11T12:39:08.731087+00:00"
        },
        {
            "id": 66762158,
            "user": "user",
            "text": "So it will be good if I got those opportunities too.",
            "created_at": "2024-12-11T12:39:12.25448+00:00"
        },
        {
            "id": 66762162,
            "user": "assistant",
            "text": `Let me tell you a bit about ${companyName}. We're a software development company that specializes in cloud-based solutions, which aligns with your interest in learning more about cloud technology. As for the work environment, we strive to maintain a collaborative and supportive atmosphere that allows our team members to grow and thrive.   Regarding the Python Developer role, some of the key responsibilities include designing and developing scalable cloud-based applications, collaborating with cross-functional teams, and contributing to the improvement of our overall technology stack. We also offer opportunities for professional growth and learning, including training and mentorship programs. Does this sound like a role that excites you?`,
            "created_at": "2024-12-11T12:39:15.12347+00:00"
        },
        {
            "id": 66762272,
            "user": "user",
            "text": "Yes. It's quite excited.",
            "created_at": "2024-12-11T12:39:55.931612+00:00"
        },
        {
            "id": 66762300,
            "user": "assistant",
            "text": "I'd like to schedule an interview with our hiring team to further discuss your qualifications and fit for the Python Developer role. What is your availability like over the next few days?",
            "created_at": "2024-12-11T12:40:18.702034+00:00"
        },
        {
            "id": 66762331,
            "user": "user",
            "text": "okay, can we schedule it at 12 PM?",
            "created_at": "2024-12-11T12:40:43.725207+00:00"
        },
        {
            "id": 66762337,
            "user": "assistant",
            "text": "That works for us. I'll make sure to send over the official interview invite. To confirm, I just need to verify your email address. Can you please confirm the email address you'd like me to send the invite to?",
            "created_at": "2024-12-11T12:40:45.53754+00:00"
        },
        {
            "id": 66762352,
            "user": "user",
            "text": "Okay. gautam@autviz.com.",
            "created_at": "2024-12-11T12:40:59.12645+00:00"
        },
        {
            "id": 66762354,
            "user": "assistant",
            "text": "Thank you for your time today, Gautam. You'll receive an email with the interview details, including the time we just confirmed, 12 PM on Monday. We'll be in touch soon. Have a great day.",
            "created_at": "2024-12-11T12:41:01.598636+00:00"
        },
        {
            "id": 66762363,
            "user": "agent-action",
            "text": "Ended call",
            "created_at": "2024-12-11T12:41:10.212604+00:00"
        }
    ]
    }

    getRestaurantPrompt(){
        return [
            {
                "id": 67236908,
                "user": "assistant",
                "text": "Hello, is this Gautam? I'm happy to take your order today, what can I get for you?",
                "created_at": "2024-12-12T11:36:02.862153+00:00"
            },
            {
                "id": 67236923,
                "user": "user",
                "text": "Get me a sandwich",
                "created_at": "2024-12-12T11:36:11.280167+00:00"
            },
            {
                "id": 67236929,
                "user": "assistant",
                "text": "What type of bread would you like for your sandwich, we have Italian, whole wheat, multigrain, or flatbread available.",
                "created_at": "2024-12-12T11:36:14.851051+00:00"
            },
            {
                "id": 67236940,
                "user": "user",
                "text": "Italian.",
                "created_at": "2024-12-12T11:36:21.770012+00:00"
            },
            {
                "id": 67236942,
                "user": "assistant",
                "text": "Now, what type of protein would you like on your Italian sandwich - we have chicken, turkey, tuna, roast beef, or a vegetarian option available.",
                "created_at": "2024-12-12T11:36:22.779756+00:00"
            },
            {
                "id": 67236957,
                "user": "user",
                "text": "Chicken.",
                "created_at": "2024-12-12T11:36:33.354574+00:00"
            },
            {
                "id": 67236964,
                "user": "assistant",
                "text": "Now that we have your protein, what vegetables would you like on your chicken sandwich - we have lettuce, tomatoes, cucumbers, onions, and bell peppers available.",
                "created_at": "2024-12-12T11:36:35.721638+00:00"
            },
            {
                "id": 67236998,
                "user": "user",
                "text": "lettuce.",
                "created_at": "2024-12-12T11:36:44.875134+00:00"
            },
            {
                "id": 67237010,
                "user": "assistant",
                "text": "You'd like lettuce on your chicken sandwich. Now, what type of sauce would-",
                "created_at": "2024-12-12T11:36:50.64518+00:00"
            },
            {
                "id": 67237015,
                "user": "user",
                "text": "Yes.",
                "created_at": "2024-12-12T11:36:52.205451+00:00"
            },
            {
                "id": 67237027,
                "user": "assistant",
                "text": "What type of sauce would you like on your chicken sandwich - we have mayo, mustard, honey mustard, sweet onion, or chipotle southwest available.",
                "created_at": "2024-12-12T11:36:56.797869+00:00"
            },
            {
                "id": 67237040,
                "user": "user",
                "text": "mayo.",
                "created_at": "2024-12-12T11:37:02.334786+00:00"
            },
            {
                "id": 67237049,
                "user": "assistant",
                "text": "Would you like to make your chicken sandwich a meal, which comes with a drink and your choice of chips or a cookie?",
                "created_at": "2024-12-12T11:37:05.636629+00:00"
            },
            {
                "id": 67237063,
                "user": "user",
                "text": "No.",
                "created_at": "2024-12-12T11:37:11.708847+00:00"
            },
            {
                "id": 67237068,
                "user": "assistant",
                "text": "Just to confirm, your order is a chicken sandwich on Italian bread with lettuce and mayo, correct?",
                "created_at": "2024-12-12T11:37:13.562868+00:00"
            },
            {
                "id": 67237081,
                "user": "user",
                "text": "Yes.",
                "created_at": "2024-12-12T11:37:18.7647+00:00"
            },
            {
                "id": 67237093,
                "user": "assistant",
                "text": "Your order will be ready at 4 PM today. Would you like to pick it up at our location or have it delivered to you?",
                "created_at": "2024-12-12T11:37:21.989786+00:00"
            },
            {
                "id": 67237113,
                "user": "user",
                "text": "Yes. Pick it up from your location.",
                "created_at": "2024-12-12T11:37:28.63078+00:00"
            },
            {
                "id": 67237120,
                "user": "assistant",
                "text": "I just need to confirm your name for the order, please.",
                "created_at": "2024-12-12T11:37:31.868761+00:00"
            },
            {
                "id": 67237130,
                "user": "user",
                "text": "Name is Gautam.",
                "created_at": "2024-12-12T11:37:36.307396+00:00"
            },
            {
                "id": 67237138,
                "user": "assistant",
                "text": "Thank you, Gautam, for your order. We appreciate your business and we'll see you at 9 PM today to pick up your chicken sandwich. Have a great day.",
                "created_at": "2024-12-12T11:37:38.255263+00:00"
            },
            {
                "id": 67237150,
                "user": "agent-action",
                "text": "Ended call",
                "created_at": "2024-12-12T11:37:44.93096+00:00"
            }
        ]
    }
    getAppointmentCallPrompt(companyName, userName){
        return [
            {
                "id": 67847427,
                "user": "assistant",
                "text": `Hi, my name is ${userName} and I'm calling from Clinic ${companyName}. Could you please tell me your name so I can -`,
                "created_at": "2024-12-13T12:11:08.865994+00:00"
            },
            {
                "id": 67847428,
                "user": "user",
                "text": "Hello.",
                "created_at": "2024-12-13T12:11:08.900817+00:00"
            },
            {
                "id": 67847440,
                "user": "user",
                "text": "It's Gautam.",
                "created_at": "2024-12-13T12:11:15.525829+00:00"
            },
            {
                "id": 67847441,
                "user": "assistant",
                "text": "Hi Gautam, I'm calling to check if you'd like to schedule an appointment with the doctor. Are you available to book something today?",
                "created_at": "2024-12-13T12:11:20.591348+00:00"
            },
            {
                "id": 67847452,
                "user": "user",
                "text": "Yes. I want to",
                "created_at": "2024-12-13T12:11:28.028947+00:00"
            },
            {
                "id": 67847454,
                "user": "assistant",
                "text": "Sur-",
                "created_at": "2024-12-13T12:11:28.949447+00:00"
            },
            {
                "id": 67847476,
                "user": "user",
                "text": "Yes. I am looking for some cleaning.",
                "created_at": "2024-12-13T12:11:42.439401+00:00"
            },
            {
                "id": 67847482,
                "user": "assistant",
                "text": "Is this just a routine cleaning, or do you have any specific concerns, like tooth pain or sensitivity, -",
                "created_at": "2024-12-13T12:11:44.932652+00:00"
            },
            {
                "id": 67847491,
                "user": "user",
                "text": "No. Just a routine one.",
                "created_at": "2024-12-13T12:11:49.355427+00:00"
            },
            {
                "id": 67847498,
                "user": "assistant",
                "text": "I think we've covered that, Gautam. I'll go ahead and schedule the appointment for you. Would you prefer morning or afternoon?",
                "created_at": "2024-12-13T12:11:55.776173+00:00"
            },
            {
                "id": 67847506,
                "user": "user",
                "text": "Afternoon.",
                "created_at": "2024-12-13T12:12:02.699005+00:00"
            },
            {
                "id": 67847533,
                "user": "assistant",
                "text": "Gautam, just to clarify, is your issue an emergency, or can it wait for a scheduled appointment?",
                "created_at": "2024-12-13T12:12:21.703462+00:00"
            },
            {
                "id": 67847542,
                "user": "user",
                "text": "I can wait for appointment.",
                "created_at": "2024-12-13T12:12:30.074374+00:00"
            },
            {
                "id": 67847559,
                "user": "assistant",
                "text": "Our next available appointment is on Monday, December 16, at 2 PM. Would that work for you, Gautam?",
                "created_at": "2024-12-13T12:12:34.634684+00:00"
            },
            {
                "id": 67847569,
                "user": "user",
                "text": "Yeah. Yeah. It's work for me",
                "created_at": "2024-12-13T12:12:41.03127+00:00"
            },
            {
                "id": 67847571,
                "user": "assistant",
                "text": "Thank you, Gautam. Have a great day",
                "created_at": "2024-12-13T12:12:42.767788+00:00"
            }
        ];
    }

    public industries = [{Name: "Real Estate", Value: PromptTypeEnumState.RealEstate},
        {Name: "HR Screening Round", Value: PromptTypeEnumState.HR},
        {Name: "Restaurant", Value: PromptTypeEnumState.Restaurant},    
        {Name: "Appointment", Value: PromptTypeEnumState.Appointment},
        {Name: "Other", Value: PromptTypeEnumState.Other}
    ]
    constructor(private http: HttpClient) {}

    /**
     * Fetch the list of countries.
     * @returns Observable of country data.
     */
    getCountries(): Observable<any[]> {
        return this.http.get<any[]>(this.apiUrl);
    }
    public getCallStatusName(callStatus){
        switch(callStatus){
            case CallMeetingEnumStatus.OfflineMeetingSc:
                return "Offline Meeting Schedule"
            case CallMeetingEnumStatus.OnlineMeetingSch:
                return "Online Meeting Schedule"
            case CallMeetingEnumStatus.Connected:
                return "Connected"
            case CallMeetingEnumStatus.NotAns:
                return "Not Answered"
        }
        return "-";

    }
    
    
}
