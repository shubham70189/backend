import { useAnimation } from '@angular/animations';
import { Component } from '@angular/core';
import { PromptTypeEnumState } from '@shared/AppEnums';
import { CommonService } from '@shared/common/Common.service';
import { CallServiceServiceProxy, PromptTypeEnum, SendCallDTO } from '@shared/service-proxies/service-proxies';
import { AppSessionService } from '@shared/session/app-session.service';

@Component({
  selector: 'app-generate-call',
  templateUrl: './generate-call.component.html',
  styleUrls: ['./generate-call.component.css']
})
export class GenerateCallComponent {
  selectedCountryCode: any;
  customer: SendCallDTO = new SendCallDTO();
  countryCodes = [];
  samplePrompt=  [];
  isLoading = false;
  promptTypeEnumState =   PromptTypeEnumState;
  constructor(private callService: CallServiceServiceProxy,
    public commonService: CommonService, private appSession: AppSessionService){
     this.customer.industry = this.appSession.user.industry
     this.onIndustryChange();
  }
  ngOnInit()
  {
    this.getCountries();
  }

  getCountries() {
    this.countryCodes = this.commonService.countries;
    let selectedCountry = this.commonService.countries.find(x=>x.countryName == this.appSession.user.country);
    if(selectedCountry?.phoneCode){
      this.selectedCountryCode = selectedCountry.phoneCode;
    }
    // this.commonService.getCountries().subscribe(res => {
    //   this.isLoading = false;
    //   res.forEach((country: any) => {
    //     if(country)
    //     {
    //       const phoneCode = (country.idd?.root ? country.idd?.root : "") + (country.idd?.suffixes?.length > 0 ? country.idd.suffixes[0] : '');
    //       if(phoneCode){
    //         if(this.appSession.user.country == country.name.common){
    //           this.selectedCountryCode = phoneCode
    //         }
    //         this.countryCodes.push( {
    //           countryName: country.name.common,
    //           phoneCode: phoneCode
    //         });
    //       }
    //   }});
    //   this.countryCodes.sort((a, b) => a.countryName.localeCompare(b.countryName));
    //   this.isLoading = false;
    //   console.log(this.countryCodes);
    // }, error=>{this.isLoading = false;});
  }
  onSubmit() {
    if (this.customer.customerNumber && this.customer.customerName) {
      this.isLoading = true;
      this.customer.customerNumber = this.selectedCountryCode+ this.customer.customerNumber
      this.customer.customerNumber = this.customer.customerNumber.replace(/\s+/g, '_');  
      this.customer.industry = PromptTypeEnumState.RealEstate;
      this.callService.sendCall(this.customer).subscribe(res=>{        
        alert('Call Enqueued');
        this.customer.customerNumber = this.customer.customerNumber.replace(this.selectedCountryCode, "");
        this.isLoading = false;
      }, err=>{
        alert('Error Occur');
      this.customer.customerNumber = this.customer.customerNumber.replace(this.selectedCountryCode, "");
      this.isLoading = false;
      })
    } else {
      alert('Error Occur');
      this.customer.customerNumber = this.customer.customerNumber.replace(this.selectedCountryCode, "");
      this.isLoading = false;
    }
  }
  onIndustryChange(){
    switch(Number(this.customer.industry)){
      case this.promptTypeEnumState.RealEstate:
        this.samplePrompt = this.commonService.getRealEstatePrompt(this.appSession.user.agencyName, this.appSession.user.name + 
          " " + this.appSession.user.surname , this.appSession.user.emailAddress);
        break;
      case this.promptTypeEnumState.HR:
        this.samplePrompt = this.commonService.getHRPrompt(this.appSession.user.agencyName, this.appSession.user.name + 
          " " + this.appSession.user.surname , this.appSession.user.emailAddress);
        break;
      case this.promptTypeEnumState.Restaurant:
        this.samplePrompt = this.commonService.getRestaurantPrompt();
        break;
      case this.promptTypeEnumState.Appointment:
          this.samplePrompt = this.commonService.getAppointmentCallPrompt(this.appSession.user.agencyName, this.appSession.user.name + 
            " " + this.appSession.user.surname);
          break;
      case this.promptTypeEnumState.Other:
        this.samplePrompt = this.commonService.getRestaurantPrompt();
        break;
    }

  }
}
