import { Component } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/core';import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction';
import { MeetingScheduleServiceServiceProxy } from '@shared/service-proxies/service-proxies';
import * as moment from '@node_modules/moment-timezone';

@Component({
  selector: 'app-meeting-calendar',
  templateUrl: './meeting-calendar.component.html',
  styleUrls: ['./meeting-calendar.component.css']
})
export class MeetingCalendarComponent {
  calendarOptions: CalendarOptions = {
    initialView: 'timeGridWeek',
    plugins: [timeGridPlugin, interactionPlugin],   
     
    events: [
      { title: 'event 1', date: '2025-01-01' },
      { title: 'event 2', date: '2025-01-02' }
    ]
  };

  /**
   *
   */
  constructor(public meetingService: MeetingScheduleServiceServiceProxy) {
    

  }
 ngOnInit(){
  
 }
}
