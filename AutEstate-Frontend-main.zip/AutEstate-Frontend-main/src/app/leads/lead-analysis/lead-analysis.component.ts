import { Component } from '@angular/core';
import { LeadAnalysisData, LeadServiceServiceProxy } from '@shared/service-proxies/service-proxies';

@Component({
  selector: 'app-lead-analysis',
  templateUrl: './lead-analysis.component.html',
  styleUrls: ['./lead-analysis.component.css']
})
export class LeadAnalysisComponent {
  analysisData = new LeadAnalysisData();

  constructor(private leadService: LeadServiceServiceProxy) {}

  ngOnInit(){
    this.getAnalysisData();
  }


  private getAnalysisData() {
    this.leadService.getAnalysisData().subscribe(res => {
      this.analysisData = res;
    });
  }
}
