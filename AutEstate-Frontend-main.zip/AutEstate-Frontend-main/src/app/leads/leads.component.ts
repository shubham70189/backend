import { Component, Injector, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { PagedListingComponentBase, PagedRequestDto } from '@shared/paged-listing-component-base';
import { BackgroundSchedulerServiceServiceProxy, DateRangeDTO, Lead, LeadDtoPagedResultDto, LeadServiceServiceProxy, PagedLeadResultRequestDto, PropertyPurposeEnum } from '@shared/service-proxies/service-proxies';
import * as moment from 'moment';
import { Router } from '@node_modules/@angular/router';
import { CallMeetingEnumStatus, LeadSourceEnumState, LeadStatusEnumState } from '@shared/AppEnums';
import { CommonService } from '@shared/common/Common.service';
import { BsModalService } from '@node_modules/ngx-bootstrap/modal';
import { UploadLeadsComponent } from './upload-leads/upload-leads.component';
import { timeStamp } from 'console';
import { AppComponentBase } from '@shared/app-component-base';

class PagedCallsRequestDto extends PagedRequestDto {
  keyword: string;
}

@Component({
  selector: 'app-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.css']
})
export class LeadsComponent  extends AppComponentBase implements OnInit {
  Leads = [];
  checkList = [];  
  allCheck = false;
  isTableLoading = false;
  skipCount : any = 0
  maxResultCount : any = 10
  totalRecords : any
  keyword = '';
  
  dateRange = {
    start: moment().startOf('month'),
    end: moment().endOf('month')
  };
  first :any
  propertyPurpose: PropertyPurposeEnum = 0;
  callMeetingEnumStatus = CallMeetingEnumStatus
  selectedLeadStatus = undefined;
  selectedLeadSource = undefined;
  LeadSource = LeadSourceEnumState;
  LeadStatus = LeadStatusEnumState;


  isFirstCall = false;
  constructor(injector: Injector, private _leadsService: LeadServiceServiceProxy,
     private router: Router, private commonservice: CommonService, 
     private modalService: BsModalService, private backgroundLead: BackgroundSchedulerServiceServiceProxy) {
    super(injector);
  }
  ngOnInit(): void {
    this.getAll();
  }
  protected delete(entity: Lead): void {
    // Delete functionality for call history (if applicable)
  }

  onDateRangeChanged(range: { start: moment.Moment; end: moment.Moment }): void {
    this.dateRange = range;
    //this.getDataPage(1);  
    this.getAll();
  }

 

  getAll()
  {
    if(!this.isFirstCall){
      this.isFirstCall = true;
      return;
    }
    this._leadsService.getAllLeads(this.keyword,this.propertyPurpose,this.dateRange.start, this.dateRange.end, this.selectedLeadSource, this.selectedLeadStatus,this.skipCount,this.maxResultCount).subscribe((res)=>{
      this.Leads = res.items;
      this.totalRecords = res.totalCount;
    })
  }
  viewCallLogs(leadId) {
    // Pass the phoneNumber as a query parameter
    this.router.navigate(['app/inbound-call'], { queryParams: { leadId: leadId } });
  }
  viewMeetings(id: number) {
    this.router.navigate(['app/meeting-schedule'], { queryParams: { LeadId: id } });
  }
  addLead(){
     let createPropertyDialog = this.modalService.show(UploadLeadsComponent, {
          class: 'modal-lg',
        });
    
        createPropertyDialog.content.onSave.subscribe(() => {
        //  this.refresh();
        });
  }
  checkUnCheckAll() {
    if (this.allCheck == true) {
      this.allCheck = false;
      this.checkList = []
    }
    else {
      this.allCheck = true;
      this.checkList = []
      for (let i of this.Leads) {
        this.checkList.push(i.id)
      }
    }
  }
  checkID(i: any) {
    var index = this.checkList.indexOf(i)
    console.log(index)
    if (index != -1) {
      this.checkList.splice(index, 1)
      this.allCheck = false
      // console.log(this.checkList)
    }
    else {
      this.checkList.push(i)
      if (this.checkList.length >= 10) {
        this.allCheck = true
      }
      else {
        this.allCheck = false
      }
      // console.log(this.checkList)
    }
  }

  bulkCall(){
    if(!this.checkList.length){
      this.notify.info("Kindly select a lead to call");
      return;
    }
    this.backgroundLead.callingOnLeadId(this.checkList).subscribe(res=>{
      this.notify.info("Call Enqueue");
    })
  }
  exportExcel(){
    var inputExportedData =  new PagedLeadResultRequestDto();
    inputExportedData.dateRange = new DateRangeDTO();
    inputExportedData.dateRange.startDate = this.dateRange.start;
    inputExportedData.dateRange.endDate = this.dateRange.end;
    inputExportedData.leadSource = this.selectedLeadSource;
    inputExportedData.leadsStatus = this.selectedLeadStatus;
    this.backgroundLead.exportLead(inputExportedData).subscribe(res=>{
      this.notify.info("Excel will be send over mail in 2 mins");
    })
  }
  viewLeadDetails(leadId: number,phoneNumber: string) {
   
    this.router.navigate(['app/lead-details'],{ queryParams: { leadId: leadId} });
  }
  onFilterChange()
  {
    if(!this.isFirstCall){
      this.isFirstCall = true;
      return;
    }
    this.getAll();

 
  }
  onClear()
  {
    this.selectedLeadSource = undefined; 
    this.selectedLeadStatus = undefined;
    this.keyword = ''
  
   this.getAll();
  
  }
  leadsDetails(event)
  {
    this.skipCount = event.skipCount;
    this.maxResultCount = event.rows;
 
    this.getAll();
  }
}
