import { Component, EventEmitter, Injector, Output } from '@angular/core';
import { AppComponentBase } from '@shared/app-component-base';
import { BackgroundSchedulerServiceServiceProxy, ExcelEnum, ExcelServiceProxy, FileType, GetMappingHeaderForLead } from '@shared/service-proxies/service-proxies';

import { BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-upload-leads',
  templateUrl: './upload-leads.component.html',
  styleUrls: ['./upload-leads.component.css']
})
export class UploadLeadsComponent extends AppComponentBase {
  file: any;
  isLoading;
  headers: string[] = [];
  mappingFields = [
    { label: 'Customer Name', field: 'customerName', selectedHeader: '' },
    { label: 'Customer Phone Number', field: 'customerPhoneNumber', selectedHeader: '' },
    { label: 'Customer Email', field: 'customerEmail', selectedHeader: '' },
  ];
 @Output() onSave = new EventEmitter<any>();
  constructor(public injector: Injector, public bsModalRef: BsModalRef, private excelService: ExcelServiceProxy,
     private backgroundService: BackgroundSchedulerServiceServiceProxy) {super(injector)}

  close(): void {
    this.bsModalRef.hide();
  }

  async onFileSelected(event: any){
    this.file = {
      fileName: event.target.files[0].name,
      data: event.target.files[0]
    };
    if (this.file) {
      this.isLoading =  true;
      let mappingResult = await this.excelService.getLeadMappingHeaders(this.file, FileType._0, ExcelEnum._0, "").toPromise();
      this.headers.push(mappingResult.customerEmail, mappingResult.customerName, mappingResult.customerPhoneNumber);
      this.mappingFields.forEach((field) => {
        field.selectedHeader = mappingResult[field.field] || '';
      });
      this.isLoading =  false;
      
    }
  }

  isMappingValid(): boolean {
    return this.mappingFields.every((field) => field.selectedHeader);
  }

  save(): void {
    if (this.file) {
      this.isLoading =  true;
      let mapping =  new GetMappingHeaderForLead();
      this.mappingFields.forEach((field) => {
        mapping[field.field] =  field.selectedHeader;
      });      
      this.backgroundService.importExcel(this.file, FileType._0, ExcelEnum._1, JSON.stringify(mapping)).subscribe(res=>{
        this.isLoading =  false;
        abp.notify.info("Leads are getting updated kindly wait for 1-2 mins");
        this.onSave.emit();
        this.bsModalRef.hide();
      }, err=>{
        this.isLoading =  false;
      })
    
    }
  }
}
