import { Component, Injector, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@node_modules/@angular/router';
import { AppComponentBase } from '@shared/app-component-base';
import { AppConsts } from '@shared/AppConsts';
import { LeadsSourceEnum,  LeadStatusEnumState } from '@shared/AppEnums';
import { BackgroundSchedulerServiceServiceProxy, CallDetailsDto, LeadDto, LeadServiceServiceProxy, MeetingScheduleDto, NotesDto, NotesServiceProxy } from '@shared/service-proxies/service-proxies';

@Component({
  selector: 'app-lead-details',
  templateUrl: './lead-details.component.html',
  styleUrls: ['./lead-details.component.css']
})
export class LeadDetailsComponent extends AppComponentBase implements OnInit {

  leadId: any
  phone: any
  leadDetails: LeadDto = new LeadDto();
  calldetails: CallDetailsDto = new CallDetailsDto();
  meetingDetails: MeetingScheduleDto = new MeetingScheduleDto();
  noteDetail: NotesDto = new NotesDto();
  noteDetails = [];
  editMode = false;
  leadStatusEnumState= LeadStatusEnumState;
  
  constructor(
    private _leadsService: LeadServiceServiceProxy,
    private route: ActivatedRoute,
    private injector: Injector,
    private _notesSerive: NotesServiceProxy,
    private router: Router,
    private backgroundLead: BackgroundSchedulerServiceServiceProxy
  ) {
    super(injector)
  }
  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      const leadId = params['leadId'];
      if (leadId) {
        this.leadId = Number(leadId);
        this.getLeadDetails();
        this.getMeetingDetails();
        this.getNotes();
        this.getCallDetails()
      }
     
    })


  }
  getLeadDetails() {


    this._leadsService.getLeadDetails(this.leadId).subscribe((res) => {
      this.leadDetails = res;
    })
  }

  getMeetingDetails() {

    this._leadsService.getMeetingDetails(this.leadId).subscribe((res) => {
      this.meetingDetails = res;
    })
  }
  getCallDetails() {

    this._leadsService.getCallDetails(this.leadId).subscribe((res) => {
      this.calldetails = res;
    })
  }

  saveNote() {
    this.noteDetail.leadId = this.leadId;
    this._notesSerive.createNotes(this.noteDetail).subscribe((res) => {
      this.notify.success("Saved Successfully");
      this.noteDetail.note = "";
      this.getNotes();
    })
  }

  getNotes() {
    this._notesSerive.getNotes(this.leadId).subscribe((res) => {
      this.noteDetails = res;
    })
  }
  async fetchRecording(call){
    window.open(`${AppConsts.remoteServiceBaseUrl}/api/CallDetail/GetRecording?callId=`+call.id)
  }
  viewCallLogs() {
    // Pass the phoneNumber as a query parameter
    this.router.navigate(['app/inbound-call'], { queryParams: { leadId: this.leadId } });
  }
  bulkCall(){    
    this.backgroundLead.callingOnLeadId([this.leadId]).subscribe(res=>{
      this.notify.info("Call Enqueue");
    })
  }
  toggleEdit() {
    this.editMode = !this.editMode;
  }

  // Method to update the lead details after editing
  updateLeadDetails() {
    this._leadsService.updateLead(this.leadDetails).subscribe((res) => {
      this.notify.success("Updated Successfully");
      this.toggleEdit(); // Disable edit mode after update
    });
  }
}







