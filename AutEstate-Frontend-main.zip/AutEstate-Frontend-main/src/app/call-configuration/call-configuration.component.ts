import { Component } from '@angular/core';
import { NotifyService } from '@node_modules/abp-ng2-module';
import { TimeTypeEnumState } from '@shared/AppEnums';
import { CallConfigurationServiceProxy, CallTimeDto, CreateCallConfigDto, RetryCallTimeDto, TimeType } from '@shared/service-proxies/service-proxies';

@Component({
  selector: 'app-call-configuration',
  templateUrl: './call-configuration.component.html',
  styleUrls: ['./call-configuration.component.css']
})
export class CallConfigurationComponent {  
  sendWhatsapp: boolean = false;
  sendFollowUpEmail: boolean = false;
  TimeTypeEnumState = TimeTypeEnumState;
  status: { apiConnection: string, callSystem: string, lastUpdated: string } = {
    apiConnection: 'Active',
    callSystem: 'Connected',
    lastUpdated: '2 minutes ago'
  };

  callConfigData: CreateCallConfigDto = new CreateCallConfigDto();

  constructor(private readonly callConfigurationService: CallConfigurationServiceProxy, public notifyService: NotifyService) { }

  ngOnInit(){
    this.callConfigData.firstCallTiming =  CallTimeDto.fromJS({
      timeType: TimeTypeEnumState.Min, // Default to "min" or adjust as needed
      value: 1,               // Default value   
    });

    this.callConfigData.maximumCallAttempts = 1;
    this.generateRetryConfigs();
    
    this.getCallConfig();
  }
  getCallConfig() {
    this.callConfigurationService.getAllCallConfig().subscribe(res=>{
      if(res.retryTime?.length)
        this.callConfigData = res;
    })
  }

  generateRetryConfigs() {
    if(this.callConfigData.maximumCallAttempts >5){
      this.notifyService.error("Max 5 retry is allowed")
      this.callConfigData.maximumCallAttempts = 5;
      this.generateRetryConfigs();
      return;
    }
    const maxAttempts = this.callConfigData.maximumCallAttempts || 0;

    // Adjust the retryConfigs array based on the maximumCallAttempts value
    this.callConfigData.retryTime  = Array.from({ length: maxAttempts }, (_, index) =>
      RetryCallTimeDto.fromJS({
        timeType: TimeTypeEnumState.Min, // Default to "min" or adjust as needed
        value: 1,               // Default value
        retryNumber: index + 1  // Assign retry numbers sequentially
      })
    );
  }

  saveChanges() {
   this.callConfigurationService.insertCallConfig(this.callConfigData).subscribe(res=>{
    this.notifyService.success("Updated Successfully");
   })
  }
}
