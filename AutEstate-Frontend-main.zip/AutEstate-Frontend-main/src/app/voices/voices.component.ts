import { Component, Injector, OnInit } from '@angular/core';
import { CallConfigurationComponent } from '@app/call-configuration/call-configuration.component';
import { AppComponentBase } from '@shared/app-component-base';
import { AppConsts } from '@shared/AppConsts';
import { CallConfigurationServiceProxy, CallDetailServiceProxy, CallServiceServiceProxy } from '@shared/service-proxies/service-proxies';

@Component({
  selector: 'app-voices',
  templateUrl: './voices.component.html',
  styleUrls: ['./voices.component.css']
})
export class VoicesComponent extends AppComponentBase implements OnInit {
  voices : any 
  id : any
constructor(private _callService: CallServiceServiceProxy ,
  private _callconfig : CallConfigurationServiceProxy,
   private injector: Injector,
)
{
  super(injector)
}

ngOnInit()
{
  this.getVoices();
 
}
getVoices() {
  this._callService.getAllVoices().subscribe({
    next: (res) => {
      this.voices = res;
      this.getSavedVoiceIds();
    },
    error: (err) => {
     
    }
  });
}
getSavedVoiceIds() {
  
  this._callconfig.getAllVoiceIds().subscribe({
    next: (voiceIds) => {
     
      this.voices?.forEach(voice => {
        if (voiceIds.includes(voice.id)) {
          voice.selected = true;
        }
      });
    },
    error: (err) => {
    
    }
  });
}
onColumnSelect(voice: any) {
  
  this.voices.forEach(row => {
    if (row.id !== voice.id) {
      row.selected = false;
    }
  });
if (voice.selected) {
    this.id = voice.id; 
  }
 
}
onsave()
{
  
  if(this.id)
  {
   this._callconfig.getVoiceId(this.id).subscribe((res)=>{
    this.notify.success("Saved Successfully");
   })
  }
}

 handleButtonClick(voiceId) {
  
  fetch(`${AppConsts.remoteServiceBaseUrl}/api/CallDetail/GenerateVoice?id=${voiceId}`)
      .then(response => response?.json())
      .then(data => {
          if (data.result.audioBase64) {
           var audio = new Audio('data:' + data.result.contentType + ';base64,' + data.result.audioBase64);
              audio.play();
          } 
        })
}
}
 